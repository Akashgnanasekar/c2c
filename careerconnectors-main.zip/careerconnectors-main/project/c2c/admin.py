from django.contrib import admin
from c2c.models import NewUser

admin.site.register(NewUser)
